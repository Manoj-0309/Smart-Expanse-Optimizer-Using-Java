import java.util.List;

public class DBCheck {
    public static void main(String[] args) {
        System.out.println("DB file: " + new java.io.File("expenses.db").getAbsolutePath());
        System.out.println("DB file exists: " + new java.io.File("expenses.db").exists());

        System.out.println("\nTesting JDBC driver availability...");
        boolean drv = Database.testConnection();
        System.out.println("Driver test result: " + drv);

        System.out.println("\nLoading transactions from DB (Database.loadAllTransactions())...");
        List<Transaction> tx = Database.loadAllTransactions();
        System.out.println("Loaded transactions: " + tx.size());
        for (Transaction t : tx) {
            System.out.println(t);
        }
    }
}
