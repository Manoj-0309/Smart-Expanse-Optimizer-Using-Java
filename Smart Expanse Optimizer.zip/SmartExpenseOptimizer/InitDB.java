public class InitDB {
    public static void main(String[] args) {
        System.out.println("Initializing database...");
        Database.init();
        System.out.println("Done.");
    }
}
