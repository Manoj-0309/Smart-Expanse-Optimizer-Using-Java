import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Database {
    private static final String DB_URL = "jdbc:sqlite:expenses.db";

    private static boolean isDriverAvailable() {
        try {
            Class.forName("org.sqlite.JDBC");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static void init() {
        if (!isDriverAvailable()) {
            System.err.println("SQLite JDBC driver NOT found. Add sqlite-jdbc.jar to the classpath.");
            System.err.println("Download from https://github.com/xerial/sqlite-jdbc/releases and run: java -cp \".;sqlite-jdbc.jar\" Main");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS transactions (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "type TEXT NOT NULL," +
                    "category TEXT," +
                    "amount REAL," +
                    "date TEXT," +
                    "description TEXT" +
                    ")";
            stmt.execute(sql);
            System.out.println("Database initialized/connected: " + DB_URL);
        } catch (SQLException e) {
            System.err.println("Failed to initialize database: " + e.getMessage());
        }
    }

    public static boolean testConnection() {
        if (!isDriverAvailable()) {
            System.err.println("Database connection test: FAILED -> SQLite JDBC driver not found on classpath.");
            return false;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            if (conn != null) {
                System.out.println("Database connection test: SUCCESS");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Database connection test: FAILED -> " + e.getMessage());
        }
        return false;
    }

    public static void saveTransaction(Transaction t) {
        if (!isDriverAvailable()) {
            System.err.println("Cannot save transaction: SQLite JDBC driver not found on classpath.");
            return;
        }

        String sql = "INSERT INTO transactions (type, category, amount, date, description) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getType().name());
            ps.setString(2, t.getCategory());
            ps.setDouble(3, t.getAmount());
            ps.setString(4, t.getDate().toString());
            ps.setString(5, t.getDescription());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Failed to save transaction: " + e.getMessage());
        }
    }

    public static List<Transaction> loadAllTransactions() {
        List<Transaction> list = new ArrayList<>();

        if (!isDriverAvailable()) {
            System.err.println("Cannot load transactions: SQLite JDBC driver not found on classpath.");
            return list;
        }

        String sql = "SELECT type, category, amount, date, description FROM transactions ORDER BY id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Transaction.Type type = Transaction.Type.valueOf(rs.getString("type"));
                String category = rs.getString("category");
                double amount = rs.getDouble("amount");
                LocalDate date = LocalDate.parse(rs.getString("date"));
                String description = rs.getString("description");
                Transaction t = new Transaction(type, category, amount, date, description);
                list.add(t);
            }
        } catch (SQLException e) {
            System.err.println("Failed to load transactions: " + e.getMessage());
        }
        return list;
    }
}
