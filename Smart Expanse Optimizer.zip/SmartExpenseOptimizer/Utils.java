import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.YearMonth;
import java.util.Map;
import java.util.Scanner;

public class Utils {

    
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static double readPositiveDouble(Scanner scanner, String prompt) {
        double value = -1;
        while (value <= 0) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                value = Double.parseDouble(line);
                if (value <= 0) {
                    System.out.println("Amount must be positive. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Please try again.");
            }
        }
        return value;
    }

    public static String readNonEmptyString(Scanner scanner, String prompt) {
        String value = "";
        while (value.isEmpty()) {
            System.out.print(prompt);
            value = scanner.nextLine().trim();
            if (value.isEmpty()) {
                System.out.println("Input cannot be empty. Please try again.");
            }
        }
        return value;
    }


    public static LocalDate readDate(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt + " (yyyy-MM-dd): ");
            String line = scanner.nextLine().trim();
            try {
                return LocalDate.parse(line, DATE_FORMAT);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please try again.");
            }
        }
    }


    public static YearMonth readYearMonth(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt + " (yyyy-MM): ");
            String line = scanner.nextLine().trim();
            try {
                return YearMonth.parse(line);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid year-month format. Please try again.");
            }
        }
    }

    public static void printExpenseBarChart(Map<String, Double> expensesByCategory) {
        if (expensesByCategory.isEmpty()) {
            System.out.println("No expenses to show for this period.");
            return;
        }

        System.out.println("\nExpenses by Category (Bar Chart):");
        System.out.println("----------------------------------");

   
        double max = 0;
        for (double value : expensesByCategory.values()) {
            if (value > max) {
                max = value;
            }
        }

      
        if (max == 0) {
            System.out.println("All expense values are zero.");
            return;
        }

       
        int maxBarLength = 40;

        for (Map.Entry<String, Double> entry : expensesByCategory.entrySet()) {
            String category = entry.getKey();
            double amount = entry.getValue();
            int barLength = (int) Math.round((amount / max) * maxBarLength);

            StringBuilder bar = new StringBuilder();
            for (int i = 0; i < barLength; i++) {
                bar.append('*');
            }

            System.out.printf("%-15s | %-10.2f | %s%n", category, amount, bar.toString());
        }

        System.out.println();
    }

    public static void printHeader(String title) {
        System.out.println("\n======================================");
        System.out.println(title);
        System.out.println("======================================");
    }
}
