import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        ExpenseManager manager = new ExpenseManager();
        Scanner scanner = new Scanner(System.in);

        boolean exit = false;
        while (!exit) {
            printMainMenu();
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    addIncomeFlow(scanner, manager);
                    break;
                case "2":
                    addExpenseFlow(scanner, manager);
                    break;
                case "3":
                    viewTransactionsFlow(manager);
                    break;
                case "4":
                    viewSummaryFlow(scanner, manager);
                    break;
                case "6":
                    testDbFlow(manager);
                    break;
                case "5":
                    exit = true;
                    System.out.println("Exiting Smart Expense Optimizer. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-6.");
                    break;
            }
        }

        scanner.close();
    }

    private static void printMainMenu() {
        Utils.printHeader("Smart Expense Optimizer - Main Menu");
        System.out.println("1. Add Income");
        System.out.println("2. Add Expense");
        System.out.println("3. View Transactions");
        System.out.println("4. View Summary");
        System.out.println("5. Exit");
        System.out.println("6. Show DB Contents");
        System.out.println("--------------------------------------");
    }

    private static void addIncomeFlow(Scanner scanner, ExpenseManager manager) {
        Utils.printHeader("Add Income");

        double amount = Utils.readPositiveDouble(scanner, "Enter income amount: ");
        String category = Utils.readNonEmptyString(scanner, "Enter income category (e.g., Salary, Bonus): ");
        LocalDate date = Utils.readDate(scanner, "Enter income date");
        System.out.print("Enter description (optional): ");
        String description = scanner.nextLine().trim();

        manager.addIncome(amount, category, date, description);
        System.out.println("Income added successfully.");
    }

    private static void addExpenseFlow(Scanner scanner, ExpenseManager manager) {
        Utils.printHeader("Add Expense");

        double amount = Utils.readPositiveDouble(scanner, "Enter expense amount: ");
        String category = Utils.readNonEmptyString(scanner, "Enter expense category (e.g., Food, Rent): ");
        LocalDate date = Utils.readDate(scanner, "Enter expense date");
        System.out.print("Enter description (optional): ");
        String description = scanner.nextLine().trim();

        manager.addExpense(amount, category, date, description);
        System.out.println("Expense added successfully.");
    }

    private static void viewTransactionsFlow(ExpenseManager manager) {
        Utils.printHeader("All Transactions");

        List<Transaction> all = manager.getAllTransactions();
        if (all.isEmpty()) {
            System.out.println("No transactions recorded yet.");
            return;
        }

        System.out.printf("%-7s | %-12s | %10s | %10s | %s%n",
                "Type", "Category", "Amount", "Date", "Description");
        System.out.println("-----------------------------------------------------------------------");

        for (Transaction t : all) {
            System.out.println(t);
        }
    }


    private static void viewSummaryFlow(Scanner scanner, ExpenseManager manager) {
        Utils.printHeader("Overall Summary");

        double totalIncome = manager.getTotalIncome();
        double totalExpense = manager.getTotalExpense();
        double balance = manager.getBalance();

        System.out.printf("Total Income : %.2f%n", totalIncome);
        System.out.printf("Total Expense: %.2f%n", totalExpense);
        System.out.printf("Balance      : %.2f%n", balance);

        System.out.println("\nFor monthly insights, please select a month.");
        YearMonth month = Utils.readYearMonth(scanner, "Enter month");

    
        Map<String, Double> expensesByCategory = manager.getExpensesByCategoryForMonth(month);
        Utils.printExpenseBarChart(expensesByCategory);

    
        List<String> alerts = manager.getBudgetAlertsForMonth(month);
        if (alerts.isEmpty()) {
            System.out.println("No budget alerts for " + month + ".");
        } else {
            System.out.println("Budget Alerts for " + month + ":");
            for (String alert : alerts) {
                System.out.println("- " + alert);
            }
        }


        System.out.println("\nSpending Suggestions for " + month + ":");
        List<String> suggestions = manager.getSpendingSuggestionsForMonth(month);
        for (String suggestion : suggestions) {
            System.out.println("- " + suggestion);
        }
    }

    private static void testDbFlow(ExpenseManager manager) {
        Utils.printHeader("DB Contents");

        java.io.File dbFile = new java.io.File("expenses.db");
        System.out.println("DB file exists: " + dbFile.exists() + "  Path: " + dbFile.getAbsolutePath());

        System.out.println("\nTransactions in DB:");
        java.util.List<Transaction> dbTransactions = Database.loadAllTransactions();
        if (dbTransactions.isEmpty()) {
            System.out.println("No transactions found in DB.");
        } else {
            System.out.printf("%-7s | %-12s | %10s | %10s | %s%n",
                    "Type", "Category", "Amount", "Date", "Description");
            System.out.println("-----------------------------------------------------------------------");
            for (Transaction t : dbTransactions) {
                System.out.println(t);
            }
        }
        System.out.println();
    }
}
