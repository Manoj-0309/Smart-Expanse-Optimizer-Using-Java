import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
public class ExpenseManager {
    private List<Transaction> transactions;
    private Map<String, Double> categoryBudgetLimits;

    public ExpenseManager() {
        Database.init();
        this.transactions = Database.loadAllTransactions();
        if (this.transactions == null) this.transactions = new ArrayList<>();
        this.categoryBudgetLimits = new HashMap<>();
        categoryBudgetLimits.put("Food", 5000.0);
        categoryBudgetLimits.put("Rent", 15000.0);
        categoryBudgetLimits.put("Entertainment", 3000.0);
        categoryBudgetLimits.put("Transport", 2000.0);
    }
    public void addIncome(double amount, String category, LocalDate date, String description) {
        Transaction t = new Transaction(Transaction.Type.INCOME, category, amount, date, description);
        transactions.add(t);
        Database.saveTransaction(t);
    }

    public void addExpense(double amount, String category, LocalDate date, String description) {
        Transaction t = new Transaction(Transaction.Type.EXPENSE, category, amount, date, description);
        transactions.add(t);
        Database.saveTransaction(t);
    }

    public List<Transaction> getAllTransactions() {
        return Collections.unmodifiableList(transactions);
    }

    public double getTotalIncome() {
        double total = 0.0;
        for (Transaction t : transactions) {
            if (t.getType() == Transaction.Type.INCOME) {
                total += t.getAmount();
            }
        }
        return total;
    }

    public double getTotalExpense() {
        double total = 0.0;
        for (Transaction t : transactions) {
            if (t.getType() == Transaction.Type.EXPENSE) {
                total += t.getAmount();
            }
        }
        return total;
    }
    public double getBalance() {
        return getTotalIncome() - getTotalExpense();
    }

    public Map<String, Double> getExpensesByCategoryForMonth(YearMonth month) {
        Map<String, Double> result = new HashMap<>();

        for (Transaction t : transactions) {
            if (t.getType() == Transaction.Type.EXPENSE) {
                YearMonth txMonth = YearMonth.from(t.getDate());
                if (txMonth.equals(month)) {
                    String category = t.getCategory();
                    double amount = t.getAmount();
                    result.put(category, result.getOrDefault(category, 0.0) + amount);
                }
            }
        }

        return result;
    }

    public List<String> getBudgetAlertsForMonth(YearMonth month) {
        List<String> alerts = new ArrayList<>();
        Map<String, Double> expensesByCategory = getExpensesByCategoryForMonth(month);

        for (Map.Entry<String, Double> entry : expensesByCategory.entrySet()) {
            String category = entry.getKey();
            double spent = entry.getValue();

            Double limit = categoryBudgetLimits.get(category);
            if (limit != null && spent > limit) {
                String msg = String.format(
                        "Alert: You exceeded your %s budget! Spent: %.2f, Limit: %.2f",
                        category, spent, limit
                );
                alerts.add(msg);
            }
        }

        return alerts;
    }


    public List<String> getSpendingSuggestionsForMonth(YearMonth month) {
        List<String> suggestions = new ArrayList<>();

        double totalIncomeForMonth = getTotalIncomeForMonth(month);
        if (totalIncomeForMonth <= 0) {
            suggestions.add("No income recorded for this month. Add income to get meaningful suggestions.");
            return suggestions;
        }

        Map<String, Double> expensesByCategory = getExpensesByCategoryForMonth(month);

        for (Map.Entry<String, Double> entry : expensesByCategory.entrySet()) {
            String category = entry.getKey();
            double spent = entry.getValue();
            double percent = (spent / totalIncomeForMonth) * 100.0;

            String base = String.format(
                    "You spent %.1f%% of your income on %s this month.",
                    percent, category
            );

            if (percent > 50) {
                base += " This is quite high. Consider reviewing this category and cutting back where possible.";
            } else if (percent > 30) {
                base += " This is a significant portion. Look for ways to optimize spending (e.g., discounts, alternatives).";
            } else if (percent > 10) {
                base += " This seems reasonable, but you can still watch for unnecessary expenses.";
            } else {
                base += " This looks manageable. Good job keeping this category under control.";
            }

            if (category.equalsIgnoreCase("Food")) {
                base += " Consider cooking at home more often instead of eating out.";
            }

            suggestions.add(base);
        }

        return suggestions;
    }

    public double getTotalIncomeForMonth(YearMonth month) {
        double total = 0.0;
        for (Transaction t : transactions) {
            if (t.getType() == Transaction.Type.INCOME) {
                YearMonth txMonth = YearMonth.from(t.getDate());
                if (txMonth.equals(month)) {
                    total += t.getAmount();
                }
            }
        }
        return total;
    }

    public Map<String, Double> getCategoryBudgetLimits() {
        return Collections.unmodifiableMap(categoryBudgetLimits);
    }
}
